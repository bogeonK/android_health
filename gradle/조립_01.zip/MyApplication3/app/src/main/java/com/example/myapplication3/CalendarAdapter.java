package com.example.myapplication3;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class CalendarAdapter extends RecyclerView.Adapter<CalendarAdapter.CalendarViewHolder>{

    TextView textview;
    ArrayList<Date> dayList;

    public CalendarAdapter(ArrayList<Date> dayList ) {
        this.dayList = dayList;
    }

    @NonNull
    @Override
    public CalendarViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater inflater = LayoutInflater.from(parent.getContext());



        View view = inflater.inflate(R.layout.calendar_cell, parent, false);

        return new CalendarViewHolder(view);
    }
    private int selectedPosition = -1;

    @Override
    public void onBindViewHolder(@NonNull CalendarViewHolder holder, @SuppressLint("RecyclerView") int position) {

        //날짜 변수에 담기
        Date monthDate = dayList.get(position);

        //달력 초기화
        Calendar dateCalendar = Calendar.getInstance();

        dateCalendar.setTime(monthDate);

        //현재 년 월
        int currentDay = CalendarUtil.selectedDate.get(Calendar.DAY_OF_MONTH);
        int currentMonth = CalendarUtil.selectedDate.get(Calendar.MONTH)+1;
        int currentYear = CalendarUtil.selectedDate.get(Calendar.YEAR);

        //넘어온 데이터
        int displayDay = dateCalendar.get(Calendar.DAY_OF_MONTH);
        int displayMonth = dateCalendar.get(Calendar.MONTH)+1;
        int displayYear = dateCalendar.get(Calendar.YEAR);

        //년, 월 같으면 진한색 아니면 연한색으로 변경
        if(displayMonth == currentMonth && displayYear == currentYear){

            holder.parentView.setBackgroundColor(Color.parseColor("#D5D5D5"));

            //날짜까지 맞으면 색상 표시
            holder.itemView.setBackgroundColor(Color.parseColor("#FFFFFF"));
            if(displayDay == currentDay){
                holder.itemView.setBackgroundResource(R.drawable.today_item);;
            }
        }else{

            holder.parentView.setBackgroundColor(Color.parseColor("#D3D3D3"));
        }

        //날짜 변수에 담기
        int dayNo = dateCalendar.get(Calendar.DAY_OF_MONTH);
        //날짜 변수에 담기

        holder.dayText.setText(String.valueOf(dayNo));


        //텍스트 색상
        if (position == selectedPosition) {
            if ((position + 1) % 7 == 0) {
                holder.dayText.setTextColor(Color.BLUE);
            } else if (position % 7 == 0) {
                holder.dayText.setTextColor(Color.RED);
            } else {
                holder.dayText.setTextColor(Color.BLACK);
            }
        } else {
            if ((position + 1) % 7 == 0) {
                holder.dayText.setTextColor(Color.BLUE);
            } else if (position % 7 == 0) {
                holder.dayText.setTextColor(Color.RED);
            } else {
                holder.dayText.setTextColor(Color.BLACK);
            }
        }
        //날짜 클릭
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (selectedPosition != -1) {
                    notifyItemChanged(selectedPosition);
                }
                // 클릭한 날짜에 테두리
                selectedPosition = position;
                holder.itemView.setBackgroundResource(R.drawable.selected_item); // 테두리 drawable
                // MainActivity에 날짜 정보 전달




            }
        });

    }

    @Override
    public int getItemCount() {
        return dayList.size();
    }

    class CalendarViewHolder extends RecyclerView.ViewHolder{

        TextView dayText;

        View parentView;


        public CalendarViewHolder(@NonNull View itemView) {
            super(itemView);

            dayText = itemView.findViewById(R.id.dayText);

            parentView = itemView.findViewById(R.id.parentView);
         //

        }
    }
}
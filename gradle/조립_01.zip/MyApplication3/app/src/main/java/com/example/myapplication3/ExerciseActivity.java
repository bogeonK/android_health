package com.example.myapplication3;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ExerciseActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.exercise_layout);

        ArrayList<ExerciseModel> dataModels = new ArrayList();
        RecyclerView ex_recyclerView;


        //데이터 모델리스트

        dataModels.add(new ExerciseModel("가슴", "c_00"));
        dataModels.add(new ExerciseModel("등", "b_00"));
        dataModels.add(new ExerciseModel("하체", "l_00"));
        dataModels.add(new ExerciseModel("어깨", "s_00"));
        dataModels.add(new ExerciseModel("이두", "bi_00"));
        dataModels.add(new ExerciseModel("삼두", "ti_00"));
        dataModels.add(new ExerciseModel("복근", "a_00"));


        ex_recyclerView = findViewById(R.id.exercise_recyclerview);
        ExerciseAdapter adapter = new ExerciseAdapter(this, dataModels);
        ex_recyclerView.setAdapter(adapter);
        ex_recyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));

        // 열생성
        ex_recyclerView.setLayoutManager(new GridLayoutManager(getApplicationContext(), 2));


        adapter.setOnItemClickListener(new ExerciseAdapter.OnItemClickListener() {

            @Override
            public void onItemClick(int position) {

                ExerciseModel clickedItem = dataModels.get(position);
                String title = clickedItem.getTitle();

                if (title.equals("가슴")) {
                    Intent intent = new Intent(getApplicationContext(), ChestActivity.class);
                    startActivity(intent);
                } else if (title.equals(("등"))) {
                    Intent intent = new Intent(getApplicationContext(), BackActivity.class);
                    startActivity((intent));

                } else if (title.equals(("하체"))) {
                    Intent intent = new Intent(getApplicationContext(), LegActivity.class);
                    startActivity((intent));

                } else if (title.equals(("어깨"))) {
                    Intent intent = new Intent(getApplicationContext(), ShoulderActivity.class);
                    startActivity((intent));

                } else if (title.equals(("이두"))) {
                    Intent intent = new Intent(getApplicationContext(), BicepsActivity.class);
                    startActivity((intent));

                } else if (title.equals(("삼두"))) {
                    Intent intent = new Intent(getApplicationContext(), TricepsActivity.class);
                    startActivity((intent));

                } else if (title.equals(("복근"))) {
                    Intent intent = new Intent(getApplicationContext(), AbsActivity.class);
                    startActivity((intent));

                }
            }
        });

    }
}

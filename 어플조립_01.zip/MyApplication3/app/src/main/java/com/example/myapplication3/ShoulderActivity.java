package com.example.myapplication3;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ShoulderActivity extends AppCompatActivity {
    private int imageCounter = 0;  // 이미지 번호를 관리하기 위한 변수

    // 동적 생성 이미지에 대한 번호 저장 어레이
    private ArrayList<Integer> selectedShoulderImageIds = new ArrayList<>();

    // 최종 운동설정 어레이 (2차원)
    private ArrayList<ArrayList<String>> shoulderDetailsList = new ArrayList<>();

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shoulder);



        ArrayList<ShoulderModel> shoulderModels = new ArrayList();
        RecyclerView recyclerView;
        Button shoulder_setting_Btn = findViewById(R.id.setting_shoulder);

        //데이터 모델리스트

        shoulderModels.add(new ShoulderModel("사이드레터럴레이즈", "s_01"));
        shoulderModels.add(new ShoulderModel("밀리터리프레스", "s_02"));
        shoulderModels.add(new ShoulderModel("덤벨숄더프레스", "s_03"));
        shoulderModels.add(new ShoulderModel("머신:숄더", "s_04"));


        recyclerView = findViewById(R.id.shoulder_recyclerview);
        ShoulderAdapter adapter = new ShoulderAdapter(this, shoulderModels);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));

        // 열생성
        recyclerView.setLayoutManager(new GridLayoutManager(getApplicationContext(), 2));
        adapter.setOnItemClickListener(new ShoulderAdapter.OnItemClickListener(){

            @Override
            public void onItemClick(int position) {
                ShoulderModel clickedItem = shoulderModels.get(position);
                String imagePath = clickedItem.getImage_path();

                // "X"를 표시할 TextView를 동적으로 생성
                TextView xTextView = new TextView(ShoulderActivity.this);
                xTextView.setText("X");
                xTextView.setTextColor(Color.RED);  // 원하는 색상으로 설정


                // 동적으로 ImageView 생성
                ImageView imageView = new ImageView(ShoulderActivity.this);
                // 이미지에 고유한 번호를 부여
                int imageNumber = ++imageCounter;

                // ImageView의 크기를 설정
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
                layoutParams.width = 100; // 원하는 가로 크기를 픽셀 단위로 설정
                layoutParams.height = 100; // 원하는 세로 크기를 픽셀 단위로 설정
                imageView.setLayoutParams(layoutParams);

                // 선택한 항목의 이미지 경로에 따라 이미지 리소스 설정
                int resId = getResources().getIdentifier(imagePath, "drawable", getPackageName());
                imageView.setImageResource(resId);

                // ImageView를 레이아웃에 추가
                LinearLayout imageLayout = findViewById(R.id.shoulder_image_layout); // 실제 레이아웃 ID로 대체
                imageLayout.addView(imageView);


                // TextView에 터치 이벤트 추가
                xTextView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // TextView를 클릭했을 때의 동작을 추가
                        // 여기에 이미지 삭제 동작을 수행하면 됩니다.
                        imageLayout.removeView(imageView);
                        imageLayout.removeView(xTextView);

                        // 이미지 넘버에 해당하는 어레이를 찾기
                        int index = selectedShoulderImageIds.indexOf(imageNumber);
                        if (index != -1) {
                            // 이미지 넘버에 해당하는 어레이 삭제
                            selectedShoulderImageIds.remove(index);
                            shoulderDetailsList.remove(index);
                        }

                    }
                });

                imageView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        // 이미지 클릭했을 때 동작
                        showExerciseDialog(clickedItem, imageNumber);


                    }
                });
                // TextView를 레이아웃에 추가
                imageLayout.addView(xTextView, layoutParams);


            }
        });


        //하단 버튼 누를시 동작 설정
        shoulder_setting_Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 어레이를 log창에서 표시
                Log.d("ExerciseActivity", "Shoulder Details List: " + shoulderDetailsList.toString());
            }
        });
    }
    private void showExerciseDialog(ShoulderModel shoulderModel, int imageNumber) {
        AlertDialog.Builder Shoulder_dlg = new AlertDialog.Builder(ShoulderActivity.this);
        Shoulder_dlg.setTitle("운동 설정");
        View dialogLayout = getLayoutInflater().inflate(R.layout.setting_dlg, null);
        Shoulder_dlg.setView(dialogLayout);

        // 다이얼로그 UI
        EditText weightEditText = dialogLayout.findViewById(R.id.dlg_set_weight);
        EditText countEditText = dialogLayout.findViewById(R.id.dlg_set_count);
        EditText workEditText = dialogLayout.findViewById(R.id.dlg_set_work);
        EditText breakEditText = dialogLayout.findViewById(R.id.dlg_set_break);
        EditText repeatEditText = dialogLayout.findViewById(R.id.dlg_set_repeat);


        int index = selectedShoulderImageIds.indexOf(imageNumber);

        // 이미 입력된 값이 있으면 해당 값을 다이얼로그에 표시
        if (index != -1) {
            ArrayList<String> setShoulderList = shoulderDetailsList.get(index);
            weightEditText.setText(setShoulderList.get(2));  // 첫 번째 값(세트 수) 설정
            countEditText.setText(setShoulderList.get(3));   // 두 번째 값(작업 시간) 설정
            workEditText.setText(setShoulderList.get(4));  // 세 번째 값(휴식 시간) 설정
            breakEditText.setText(setShoulderList.get(5)); // 네 번째 값(반복 횟수) 설정
            repeatEditText.setText(setShoulderList.get(6)); // 다섯 번째 값(중량) 설정
        }


        Shoulder_dlg.setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String title = shoulderModel.getTitle();
                // shoulderModel 및 imageNumber를 활용하여 현재 클릭된 이미지에 대한 정보에 접근
                // 이미지 번호로 해당 이미지의 어레이를 찾기
                int index = selectedShoulderImageIds.indexOf(imageNumber);
                if (index != -1) {
                    // 기존 이미지의 어레이가 존재하면 수정
                    ArrayList<String> setShoulderList = shoulderDetailsList.get(index);

                    // 다이얼로그에서 입력된 값을 얻어와서 어레이를 수정
                    setShoulderList.set(2, weightEditText.getText().toString());    // 중량
                    setShoulderList.set(3, countEditText.getText().toString());     // 세트수
                    setShoulderList.set(4, workEditText.getText().toString());      // 운동 시간
                    setShoulderList.set(5, breakEditText.getText().toString());     // 휴식 시간
                    setShoulderList.set(6, repeatEditText.getText().toString());    // 반복 횟수
                } else {
                    // 이미지의 어레이가 존재하지 않으면 새로운 어레이를 추가
                    ArrayList<String> newSetShoulderList = new ArrayList<>();
                    newSetShoulderList.add("어깨");  // 부위
                    newSetShoulderList.add(title); // 운동이름
                    newSetShoulderList.add(weightEditText.getText().toString());    // 중량
                    newSetShoulderList.add(countEditText.getText().toString());     // 세트수
                    newSetShoulderList.add(workEditText.getText().toString());      // 운동 시간
                    newSetShoulderList.add(breakEditText.getText().toString());     // 휴식 시간
                    newSetShoulderList.add(repeatEditText.getText().toString());    // 반복 횟수


                    // 이미지 넘버에 해당하는 어레이를 추가
                    selectedShoulderImageIds.add(imageNumber);
                    shoulderDetailsList.add(newSetShoulderList);
                }

            }
        });

        Shoulder_dlg.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        Shoulder_dlg.show();
    }
}

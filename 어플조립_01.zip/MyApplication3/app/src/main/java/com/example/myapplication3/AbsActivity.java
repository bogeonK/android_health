package com.example.myapplication3;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AbsActivity extends AppCompatActivity {
    private int imageCounter = 0;  // 이미지 번호를 관리하기 위한 변수

    // 동적 생성 이미지에 대한 번호 저장 어레이
    private ArrayList<Integer> selectedAbsImageIds = new ArrayList<>();

    // 최종 운동설정 어레이 (2차원)
    private ArrayList<ArrayList<String>> absDetailsList = new ArrayList<>();

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abs);

        ArrayList<AbsModel> absModels = new ArrayList();
        RecyclerView recyclerView;
        Button abs_setting_Btn = findViewById(R.id.setting_abs);

        //데이터 모델리스트

        absModels.add(new AbsModel("윗몸일으키기", "a_01"));
        absModels.add(new AbsModel("플랭크", "a_02"));
        absModels.add(new AbsModel("크런치", "a_03"));


        recyclerView = findViewById(R.id.abs_recyclerview);
        AbsAdapter adapter = new AbsAdapter(this, absModels);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));

        // 열생성
        recyclerView.setLayoutManager(new GridLayoutManager(getApplicationContext(), 2));
        adapter.setOnItemClickListener(new AbsAdapter.OnItemClickListener(){

            @Override
            public void onItemClick(int position) {
                AbsModel clickedItem = absModels.get(position);
                String imagePath = clickedItem.getImage_path();

                // "X"를 표시할 TextView를 동적으로 생성
                TextView xTextView = new TextView(AbsActivity.this);
                xTextView.setText("X");
                xTextView.setTextColor(Color.RED);  // 원하는 색상으로 설정


                // 동적으로 ImageView 생성
                ImageView imageView = new ImageView(AbsActivity.this);
                // 이미지에 고유한 번호를 부여
                int imageNumber = ++imageCounter;

                // ImageView의 크기를 설정
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
                layoutParams.width = 100; // 원하는 가로 크기를 픽셀 단위로 설정
                layoutParams.height = 100; // 원하는 세로 크기를 픽셀 단위로 설정
                imageView.setLayoutParams(layoutParams);

                // 선택한 항목의 이미지 경로에 따라 이미지 리소스 설정
                int resId = getResources().getIdentifier(imagePath, "drawable", getPackageName());
                imageView.setImageResource(resId);

                // ImageView를 레이아웃에 추가
                LinearLayout imageLayout = findViewById(R.id.abs_image_layout); // 실제 레이아웃 ID로 대체
                imageLayout.addView(imageView);


                // TextView에 터치 이벤트 추가
                xTextView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // TextView를 클릭했을 때의 동작을 추가
                        // 여기에 이미지 삭제 동작을 수행하면 됩니다.
                        imageLayout.removeView(imageView);
                        imageLayout.removeView(xTextView);

                        // 이미지 넘버에 해당하는 어레이를 찾기
                        int index = selectedAbsImageIds.indexOf(imageNumber);
                        if (index != -1) {
                            // 이미지 넘버에 해당하는 어레이 삭제
                            selectedAbsImageIds.remove(index);
                            absDetailsList.remove(index);
                        }

                    }
                });

                imageView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        // 이미지 클릭했을 때 동작
                        showExerciseDialog(clickedItem, imageNumber);


                    }
                });
                // TextView를 레이아웃에 추가
                imageLayout.addView(xTextView, layoutParams);


            }
        });


        //하단 버튼 누를시 동작 설정
        abs_setting_Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 어레이를 log창에서 표시
                Log.d("ExerciseActivity", "Abs Details List: " + absDetailsList.toString());
            }
        });
    }
    private void showExerciseDialog(AbsModel absModel, int imageNumber) {
        AlertDialog.Builder Abs_dlg = new AlertDialog.Builder(AbsActivity.this);
        Abs_dlg.setTitle("운동 설정");
        View dialogLayout = getLayoutInflater().inflate(R.layout.setting_dlg, null);
        Abs_dlg.setView(dialogLayout);

        // 다이얼로그 UI
        EditText weightEditText = dialogLayout.findViewById(R.id.dlg_set_weight);
        EditText countEditText = dialogLayout.findViewById(R.id.dlg_set_count);
        EditText workEditText = dialogLayout.findViewById(R.id.dlg_set_work);
        EditText breakEditText = dialogLayout.findViewById(R.id.dlg_set_break);
        EditText repeatEditText = dialogLayout.findViewById(R.id.dlg_set_repeat);


        int index = selectedAbsImageIds.indexOf(imageNumber);

        // 이미 입력된 값이 있으면 해당 값을 다이얼로그에 표시
        if (index != -1) {
            ArrayList<String> setAbsList = absDetailsList.get(index);
            weightEditText.setText(setAbsList.get(2));  // 첫 번째 값(세트 수) 설정
            countEditText.setText(setAbsList.get(3));   // 두 번째 값(작업 시간) 설정
            workEditText.setText(setAbsList.get(4));  // 세 번째 값(휴식 시간) 설정
            breakEditText.setText(setAbsList.get(5)); // 네 번째 값(반복 횟수) 설정
            repeatEditText.setText(setAbsList.get(6)); // 다섯 번째 값(중량) 설정
        }


        Abs_dlg.setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String title = absModel.getTitle();
                // absModel 및 imageNumber를 활용하여 현재 클릭된 이미지에 대한 정보에 접근
                // 이미지 번호로 해당 이미지의 어레이를 찾기
                int index = selectedAbsImageIds.indexOf(imageNumber);
                if (index != -1) {
                    // 기존 이미지의 어레이가 존재하면 수정
                    ArrayList<String> setAbsList = absDetailsList.get(index);

                    // 다이얼로그에서 입력된 값을 얻어와서 어레이를 수정
                    setAbsList.set(2, weightEditText.getText().toString());    // 중량
                    setAbsList.set(3, countEditText.getText().toString());     // 세트수
                    setAbsList.set(4, workEditText.getText().toString());      // 운동 시간
                    setAbsList.set(5, breakEditText.getText().toString());     // 휴식 시간
                    setAbsList.set(6, repeatEditText.getText().toString());    // 반복 횟수
                } else {
                    // 이미지의 어레이가 존재하지 않으면 새로운 어레이를 추가
                    ArrayList<String> newSetAbsList = new ArrayList<>();
                    newSetAbsList.add("복근");  // 부위
                    newSetAbsList.add(title); // 운동이름
                    newSetAbsList.add(weightEditText.getText().toString());    // 중량
                    newSetAbsList.add(countEditText.getText().toString());     // 세트수
                    newSetAbsList.add(workEditText.getText().toString());      // 운동 시간
                    newSetAbsList.add(breakEditText.getText().toString());     // 휴식 시간
                    newSetAbsList.add(repeatEditText.getText().toString());    // 반복 횟수


                    // 이미지 넘버에 해당하는 어레이를 추가
                    selectedAbsImageIds.add(imageNumber);
                    absDetailsList.add(newSetAbsList);
                }

            }
        });

        Abs_dlg.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        Abs_dlg.show();
    }
}
